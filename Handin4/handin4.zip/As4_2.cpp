#include "assignment4-2.hpp"
#include <iostream>
// using namespace std;

int main() {
  // computeDistances(SetIterator begin, SetIterator end, const Vector &query, DistanceIterator distanceBegin)

  // std::vector<int> myvector;
  // for (int i=1; i<=5; i++) myvector.push_back(i);
  // for (std::vector<int>::iterator it = myvector.begin() ; it != myvector.end(); ++it) *it = 7;

  // std::cout << "myvector contains:";
  // for (std::vector<int>::iterator it = myvector.begin() ; it != myvector.end(); ++it)
  //   std::cout << ' ' << *it;
  // std::cout << '\n';

  return 0;
}